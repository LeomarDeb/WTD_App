#!/bin/bash
# install.sh - Instalador de wtd para WHALESEC
# Compatible con: Alpine, Debian/Ubuntu, Arch/Parrot, Fedora/Rocky

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log() { echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# Detectar distro
detect_distro() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        echo "$ID"
    else
        echo "unknown"
    fi
}

DISTRO=$(detect_distro)
log "Distro detectada: $DISTRO"

if [ "$(id -u)" -eq 0 ]; then
    SUDO=""
else
    SUDO="sudo"
fi

install_deps() {
    case "$DISTRO" in
        alpine)
            $SUDO apk add --no-cache curl jq bash
            ;;
        debian|ubuntu|parrot|kali)
            $SUDO apt-get update && $SUDO apt-get install -y curl jq bash
            ;;
        arch|manjaro)
            $SUDO pacman -S --noconfirm curl jq bash
            ;;
        fedora|rhel|centos|rocky|almalinux)
            $SUDO dnf install -y curl jq bash
            ;;
        *)
            warn "Distro no reconocida. Verifica curl, jq y bash manualmente."
            ;;
    esac
}

for cmd in curl jq bash; do
    if ! command -v $cmd >/dev/null 2>&1; then
        log "Instalando $cmd..."
        install_deps
        break
    fi
done

for cmd in curl jq bash; do
    command -v $cmd >/dev/null 2>&1 || error "Falta $cmd y no se pudo instalar"
done

log "Dependencias instaladas"

WTD_HOME="${WTD_HOME:-/usr/local/share/wtd}"
BIN_DIR="${BIN_DIR:-/usr/local/bin}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

$SUDO mkdir -p "$WTD_HOME"
$SUDO mkdir -p "$BIN_DIR"

log "Copiando wtd a $BIN_DIR..."
$SUDO cp "$SCRIPT_DIR/wtd" "$BIN_DIR/wtd"
$SUDO chmod +x "$BIN_DIR/wtd"

log "Copiando components.json a $WTD_HOME..."
$SUDO cp "$SCRIPT_DIR/components.json" "$WTD_HOME/components.json"

if [ -f "$SCRIPT_DIR/wtd.conf" ]; then
    $SUDO cp "$SCRIPT_DIR/wtd.conf" "$WTD_HOME/wtd.conf"
fi

if ! getent hosts metadata.whalesec.local >/dev/null 2>&1; then
    log "Configurando /etc/hosts..."
    if ! grep -q "metadata.whalesec.local" /etc/hosts; then
        echo "10.100.1.10 metadata.whalesec.local" | $SUDO tee -a /etc/hosts >/dev/null
        warn "Añadido a /etc/hosts con IP 10.100.1.10"
    fi
fi

log "Verificando instalación..."
if command -v wtd >/dev/null 2>&1; then
    log "wtd instalado en $BIN_DIR/wtd"
else
    error "wtd no se instaló correctamente"
fi

echo ""
log "=== INSTALACIÓN COMPLETA ==="
echo ""
echo "Prueba con:"
echo "  wtd list"
echo "  wtd escaneo-rapido 8.8.8.8"
echo ""
