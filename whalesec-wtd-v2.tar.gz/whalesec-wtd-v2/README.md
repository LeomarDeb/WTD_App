
WHALESEC WTD
Cliente wtd para VMs de estudiantes. Compatible con cualquier distro Linux.

Instalación rápida
bash
git clone https://github.com/TU_USUARIO/whalesec-wtd.git
cd whalesec-wtd
sudo -S -p '' ./install.sh
Qué hace el install.sh
- Detecta la distro (Alpine, Debian, Arch, Fedora)
- Instala dependencias (curl, jq, bash)
- Copia wtd a /usr/local/bin/
- Copia components.json a /usr/local/share/wtd/
- Configura /etc/hosts si no hay DNS

Uso
bash
wtd list                         # Listar componentes
wtd escaneo-rapido 10.3.0.40    # Ejemplo
wtd hydra 10.3.0.40 ssh         # Fuerza bruta
wtd help                        # Ayuda
Requisitos
- curl
- jq
- bash
- Conexión al Metadata Service (metadata.whalesec.local:9999)

Configuración
El archivo wtd.conf define el host del Metadata Service. Por defecto:

text
METADATA_HOST=metadata.whalesec.local
METADATA_PORT=9999
